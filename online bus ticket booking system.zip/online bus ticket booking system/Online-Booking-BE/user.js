const express = require('express');
const router = express.Router();
const connection = require('./connection');

// GET route to fetch all buses
router.get('/buses', (req, res) => {
    const query = "SELECT * FROM buses";
    connection.query(query, (err, results) => {
        if (err) {
            return res.status(500).json({ error: err.message });
        }
        return res.status(200).json(results);
    });
});

// GET route to fetch bus details
router.get('/bus_details', (req, res) => {
    console.log('Call received from API');
    const { pickup, drop } = req.query;
    console.log(pickup,drop);// Use req.query for GET requests
    if (!pickup || !drop) {
        return res.status(400).json({ error: 'Pickup and drop locations are required' });
    }

    const upperStart = pickup.toUpperCase();
    const upperDestination = drop.toUpperCase();

    const query = 'SELECT * FROM buses WHERE startpoint = ? AND destination = ?';

    connection.query(query, [upperStart, upperDestination], (err, results) => {
        console.log('Entered query callback');
        if (err) {
            console.log(err);
            return res.status(500).json({ error: err.message });
        }
        console.log('About to fetch results');
        
        if (results.length > 0) {
            console.log(results);
            return res.status(200).json(results);
        } else {
            console.log(`No bus that takes you from ${upperStart} to ${upperDestination}`);
            return res.status(404).json({ message: 'No bus found for the specified route' });
        }
    });
});


// POST route to book a bus
router.post('/book', (req, res) => {
    const { id, c_name, b_name, pickup, drop, seat_no } = req.body;

    const queryCheckBus = 'SELECT * FROM buses WHERE startpoint = ? AND destination = ?';
    const queryBook = 'INSERT INTO bookings VALUES (?, ?, ?, ?, ?, ?)';
    const query_for_bookedtable = 'INSERT INTO booked VALUES (?, ?, ?, ?, ?, ?)';

    // Check if a bus is available between the given pickup and drop locations
    connection.query(queryCheckBus, [pickup, drop], (err, busResults) => {
        if (err) {
            console.error('Error while checking bus availability:', err);
            return res.status(500).json({ error: 'Error while checking bus availability' });
        }

        // Check if any buses were found
        if (busResults.length > 0) {
            const busDetails = busResults[0]; // Assuming you book on the first bus found

            console.log("Bus found. Proceeding with booking.");

            // Proceed with booking the ticket
            connection.query(queryBook, [id, c_name, b_name, pickup, drop, seat_no], (err, bookingResults) => {
                if (err) {
                    console.error('Error while booking:', err);
                    return res.status(500).json({ error: 'Error while booking' });
                }

                // Insert into booked table
                connection.query(query_for_bookedtable, [
                    id,
                    c_name,
                    seat_no,
                    busDetails.bus_name, // Use the bus name from busDetails
                    busDetails.start_time,
                    busDetails.reach_time,
                     // Assuming this is the missing parameter
                ], (err, bookedResults) => {
                    if (err) {
                        console.error('Error while inserting into booked table:', err);
                        return res.status(500).json({ error: 'Error while inserting into booked table' });
                    }

                    console.log('Booked successfully!!');
                    return res.status(201).json({ message: 'Booking successful' });
                });
            });
        } else {
            console.log(pickup,drop)
            console.log("No bus available for the selected route. ");
            return res.status(404).json({ message: 'No bus available for the selected route',pickup,drop });
        }
    });
});






// GET route to fetch all bookings
router.get('/get_all_tck', (req, res) => {
    const query = 'SELECT * FROM bookings';
    connection.query(query, (err, results) => {
        if (err) {
            console.log(err);
            return res.status(500).json({ error: err.message });
        }
        console.log('All tickets fetched successfully!');
        return res.status(200).json(results);
    });
});

router.get('/get_mytck', (req, res) => {
    const { id, c_name } = req.query;

    // Ensure bus_name is not NULL before attempting to join
    const query = 'select * from bookings b1 left join buses b2 on b1.bus_name=b2.bus_name where b1.ticket_id=?';

    connection.query(query, [id], (err, results) => {
        if (err) {
            console.log('Error:', err);
            return res.status(500).json({ error: err.message });
        }
        
        if (results.length > 0) {
            console.log('Ticket fetched successfully:', results);
            return res.status(200).json(results);
        } else {
            console.log("No ticket booked for the corresponding ID or name");
            return res.status(404).json({ message: "No ticket found" });
        }
    });
});


// DELETE route to cancel a ticket
router.delete('/cancle_tck', (req, res) => {
    const { id, c_name } = req.query;
    const querySelect = 'SELECT * FROM bookings WHERE ticket_id = ?';
    const queryDelete = 'DELETE FROM bookings WHERE ticket_id = ? AND traveller_name = ?';
    const queryInsert = 'INSERT INTO canceled_tck VALUES (?, ?, ?, ?, ?)';

    // First, fetch the details of the ticket to be deleted
    connection.query(querySelect, [id], (err, results) => {
        if (err) {
            console.log(err);
            return res.status(500).json({ error: err.message });
        }

        if (results.length > 0) {
            const toBeDeleted = results[0]; // Access the first element of the results array
            console.log('Details of ticket to be deleted:', toBeDeleted);

            // Delete the ticket
            connection.query(queryDelete, [id, c_name], (err, deleteResults) => {
                if (err) {
                    console.log(err);
                    return res.status(500).json({ error: err.message });
                }

                // Check if any rows were affected
                if (deleteResults.affectedRows > 0) {
                    console.log(`Ticket with id ${id} and name ${c_name} is successfully canceled!`);

                    // Insert into canceled_tck
                    connection.query(queryInsert, [
                        toBeDeleted.ticket_id,
                        toBeDeleted.traveller_name,
                        toBeDeleted.bus_name,
                        toBeDeleted.pickup_point, // Ensure these match the column names in your table
                        toBeDeleted.destination_point // Ensure these match the column names in your table
                    ], (err, insertResults) => {
                        if (err) {
                            console.log(err);
                            return res.status(500).json({ error: err.message });
                        } else {
                            console.log('Inserted into canceled_tck table');
                            return res.status(200).json({ message: 'Ticket successfully canceled' });
                        }
                    });
                } else {
                    console.log("No such ticket is booked");
                    return res.status(404).json({ message: 'No ticket found to cancel' });
                }
            });
        } else {
            console.log('No such ticket');
            return res.status(404).json({ message: 'No ticket found with the given ID' });
        }
    });
});
router.get('/get_details_by_name', (req, res) => {
    console.log('Reached');
    
    const query = 'SELECT * FROM buses WHERE bus_name = ?';
    const bus_name = req.query.bus_name; // Accessing the bus_name from the query parameters
    
    connection.query(query, [bus_name], (err, result) => { // Passing the bus_name as a parameter to the query
        if (err) {
            console.log(err);
            return res.status(500).json(err);
        } else if (result.length > 0) {
            console.log(result);
            return res.status(200).json(result);
        } else {
            return res.status(404).json({ message: 'Bus not found' });
        }
    });
});


router.get('/booked_seats', (req, res) => {
    const bus_name=req.query.bus_name;
    const query = 'SELECT seat_no FROM bookings where bus_name=?';
    connection.query(query,[bus_name], (err, result) => {
        if (err) {
            console.error('Error while fetching seat numbers');
            return res.status(500).json({ error: 'Database query failed' });
        } else {
            console.log('Booked seats fetched successfully');
            return res.status(200).json(result); // Return the result as an array
        }
    });
});

 // Assuming you have a connection file for the database

router.get('/get_last_tck', (req, res) => {
    // Query to select the last ticket ID from the bookings table
    const query = 'SELECT ticket_id FROM bookings ORDER BY ticket_id DESC LIMIT 1';

    connection.query(query, (error, results) => {
        if (error) {
            console.error(error);
            return res.status(500).json({ error: 'Database query failed' });
        } else if (results.length === 0) {
            return res.status(404).json({ message: 'No bookings found' });
        } else {
            return res.status(200).json(results[0]); // Send the first result
        }
    });
});

module.exports = router; // Ensure you export the router to use it in your app


module.exports = router;
