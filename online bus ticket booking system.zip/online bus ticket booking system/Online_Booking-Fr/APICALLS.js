function booktck(){
    const bookingData = {
        id: '12314',
        c_name: 'John Doe',
        b_name: 'CLR-CPT-01',
        pickup: document.getElementById('pickup').value,
        drop: document.getElementById('drop').value,
        seat_no: '12A'
    };
    
    fetch('http://localhost:8080/user/book', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(bookingData)
    })
    .then(response => response.json())
    .then(data => {
        if (data.error) {
            console.error('Error:', data.error);
        } else {
            console.log('Booking successful:', data.message);
        }
    })
    .catch((error) => {
        console.error('Error:', error);
    });
    }
function findbuses(){
    pickup_name=document.getElementById('pickup').value;
    drop_name=document.getElementById('drop').value;
    getbus_data={
        pickup:'GUNTUR',
        drop:'NARASARAOPET'
    }
     fetch('https://localhost:8080/user/bus_details',{
        method:'GET',
        headers:{
            'Content-Type':'application/json'
        },
        body:JSON.stringify(getbus_data)
     })
     .then(response=>response.json())
     .then(data => {
        if (data.error) {
            console.error('Error:', data.error);
        } else {
            console.log('Booking successful:', data.message);
        }
    })
    .catch((error) => {
        console.error('Error:', error);
    });
}
