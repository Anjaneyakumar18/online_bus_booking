var bus_name_export='';
var picking_station=''
var droping_station=''

function getbuses() {
    // Show the bookticket container when starting the search
    document.querySelector('#bookticket-cont').style.display = 'block';

    var pickup = encodeURIComponent(document.querySelector('#booking-pickup').value);
    var drop = encodeURIComponent(document.querySelector('#booking-drop').value);
    var url = `http://localhost:8080/user/bus_details?pickup=${pickup}&drop=${drop}`;

    fetch(url, {
        method: 'GET',
        headers: {
            'Content-Type': 'application/json'
        }
    })
    .then(response => {
        if (!response.ok) {
            if (response.status === 404) {
                document.querySelector('.no-bus').style.display = 'block';
            }
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        return response.json();
    })
    .then(data => {
        console.log(data);

        var table = document.querySelector('#bookticket-cont table');
        table.innerHTML = ''; // Clear existing rows

        // Hide the no-bus message since we have results
        document.querySelector('.no-bus').style.display = 'none';

        if (Array.isArray(data)) {
            data.forEach((bus, i) => {
                let tr = document.createElement('tr');

                let td1 = document.createElement('td');
                td1.innerText = bus.bus_name;
                tr.append(td1);

                let td2 = document.createElement('td');
                let button1 = document.createElement('button');
                button1.innerText = 'Bus Details';
                td2.append(button1);
                tr.append(td2);

                let td3 = document.createElement('td');
                let button2 = document.createElement('button');
                button2.innerText = 'Book';
                button2.style.backgroundColor = 'green';
                td3.append(button2);
                tr.append(td3);

                setTimeout(() => {
                    table.append(tr);

                    // Attach event listeners to the buttons after the row is added
                    button1.addEventListener('click', function () {
                        let firstTd = tr.querySelector('td');
                        console.log('First TD data:', firstTd.innerText);

                        const bus_name = encodeURIComponent(firstTd.innerText);

                        const details_url = `http://localhost:8080/user/get_details_by_name?bus_name=${bus_name}`;

                        fetch(details_url, {
                            method: 'GET',
                            headers: {
                                'Content-Type': 'application/json'
                            }
                        })
                        .then(response => {
                            if (response.status === 404) {
                                alert('No details found for this bus');
                                return;
                            }
                            if (!response.ok) {
                                return response.json().then(err => { throw new Error(err.message); });
                            }
                            return response.json();
                        })
                        .then(data => {
                            details_for_booking=data;
                            console.log('Bus details:', data);

                            document.querySelector('#bookticket-cont table').style.display='none';

                            data.forEach((detail, j) => {
                                document.querySelector('#one_bus_detail').style.display='block';
                                document.querySelector('#one_bus_detail #bus_id').innerText=data[0].id;
                                document.querySelector('#one_bus_detail #bus_name').innerText=data[0].bus_name;
                                bus_name_export=data[0].bus_name
                                document.querySelector('#one_bus_detail #Start_point').innerText=data[0].startpoint;
                                picking_station=data[0].startpoint;
                                droping_station=data[0].destination;
                                document.querySelector('#one_bus_detail #Destination_point').innerText=data[0].destination;                                
                                document.querySelector('#one_bus_detail #Start_time').innerText=data[0].start_time;
                                document.querySelector('#one_bus_detail #Reach_time').innerText=data[0].reach_time;
                                
                                setTimeout(() => {
                                    details_table.appendChild(detail_tr);
                                }, 300 * j);
                            });
                        })
                        .catch((error) => {
                            console.error('Error:', error);
                        });
                    });

                    button2.addEventListener('click', function () {
                        let firstTd = tr.querySelector('td');
                        console.log('Book:', firstTd.innerText);
                    });

                }, 300 * i);
            });
        } else {
            console.error('Unexpected data format:', data);
        }
    })
    .catch(error => {
        console.error('Error:', error);
    });
}
function book_final(){
    document.getElementById('bookticket-cont').style.display='none';
    document.getElementById('select-seat').style.display='block';
}







//exporting   
window.bus_name_export=bus_name_export;
window.pickup=picking_station;
window.destination=droping_station;