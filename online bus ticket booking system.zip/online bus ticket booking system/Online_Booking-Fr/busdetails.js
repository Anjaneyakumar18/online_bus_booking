function pickuptodestination() {
    const pickup_name = document.querySelector('#busdetails-cont .container #pickup').value.toUpperCase();
    const drop_name = document.querySelector('#busdetails-cont .container #drop').value.toUpperCase();

    // Encode the parameters to safely include them in the URL
    const url = `http://localhost:8080/user/bus_details?pickup=${encodeURIComponent(pickup_name)}&drop=${encodeURIComponent(drop_name)}`;

    fetch(url, {
        method: 'GET',
        headers: {
            'Content-Type': 'application/json'
        }
    })
    .then(response => {
        if (response.status === 404) {
            alert('No bus found from '+pickup_name+" to "+drop_name);
            return; 
        }
        if (!response.ok) {
            return response.json().then(err => { throw new Error(err.message); });
        }
        return response.json();
    })
    .then(data => {
        console.log('Bus details:', data);

        const table = document.querySelector('#busdetails-cont table');

        for (let i = 0; i < data.length; i++) { // Iterate correctly
            const tr = document.createElement('tr');

            const td1 = document.createElement('td');
            td1.innerText = data[i].id; // Correctly access the index
            tr.appendChild(td1);

            const td2 = document.createElement('td');
            td2.innerText = data[i].bus_name; // Correctly access bus_name
            tr.appendChild(td2);

            const td3 = document.createElement('td');
            td3.innerText = data[i].startpoint; // Correctly access startpoint
            tr.appendChild(td3);

            const td4 = document.createElement('td');
            td4.innerText = data[i].destination; // Correctly access destination
            tr.appendChild(td4);

            const td5 = document.createElement('td');
            td5.innerText = data[i].start_time; // Correctly access start_time
            tr.appendChild(td5);

            const td6 = document.createElement('td');
            td6.innerText = data[i].reach_time; // Correctly access reach_time
            tr.appendChild(td6);

            setTimeout(() => {
                table.appendChild(tr);
            }, 300 * i);
        }
    })
    .catch((error) => {
        console.error('Error:', error);
    });
}
