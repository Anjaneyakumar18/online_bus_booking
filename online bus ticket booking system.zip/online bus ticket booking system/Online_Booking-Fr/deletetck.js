var delete_msg = document.getElementById('cancle-msg');
var delete_sucess = document.getElementById('cancle-sucess');
console.log('loaded');

function cancle_tck() {
    console.log('entered func');
    var id = document.getElementById('id_to_cancle_tck').value;
    var name = document.getElementById('name_to_cancle_tck').value;
    const url = `http://localhost:8080/user/cancle_tck?id=${encodeURIComponent(id)}&c_name=${encodeURIComponent(name)}`;
    
    fetch(url, {
        method: 'DELETE',
        headers: {
            'Content-Type': 'application/json'
        }
    }).then(response => {
        if (!response.ok) {
            console.log('Error while deleting');
            console.log(response);
        }else if(response.message==='No ticket found to cancel'){
            alert('no such ticket');
        } 
        else{
            delete_msg.style.display = 'none';
            delete_sucess.style.display = 'block';
            console.log('Ticket canceled successfully!');
        }
    }).catch(error => {
        console.log('Fetch error:', error);
    });
}
