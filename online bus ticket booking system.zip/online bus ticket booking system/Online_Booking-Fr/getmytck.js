function getmytck() {
    var id = document.getElementById('ticket_id_to_get_tck').value;
    var c_name = 'John Doe';
    const url = `http://localhost:8080/user/get_mytck?id=${encodeURIComponent(id)}&c_name=${encodeURIComponent(c_name)}`;

    fetch(url, {
        method: 'GET',
        headers: {
            'Content-Type': 'application/json'
        }
    })
    .then(response => {
        if (response.status === 404) {
            setTimeout(() => {
                alert('No ticket found');
            }, 200);
            document.getElementById('ticket-details-table').style.display = 'none'; // Hide the table if no ticket is found
            return null;
        }
        if (!response.ok) {
            throw new Error(`Error: ${response.statusText}`);
        }
        return response.json(); // Parse JSON response
    })
    .then(data => {
        if (data) {
            document.getElementById('ticket-details-table').style.display = 'table'; // Show the table
            console.log('Ticket data:', data);
            document.getElementById('t_id').innerText = data[0].ticket_id;
            document.getElementById('c_n').innerText = data[0].traveller_name;
            document.getElementById('b_n').innerText = data[0].bus_name;
            document.getElementById('p_p').innerText = data[0].startpoint;
            document.getElementById('d_p').innerText = data[0].destination;
            document.getElementById('s_t').innerText = data[0].start_time;
            document.getElementById('r_t').innerText = data[0].reach_time;
        }
    })
    .catch(error => {
        console.error('Fetch error:', error);
    });
}
