var booked = [];
var ticket_id_book = 0; // Initialize with zero or your starting value
var selected_seats = [];
let alltck = [];
var url2 = 'http://localhost:8080/user/get_last_tck';

fetch(url2, {
    method: 'GET',
    headers: {
        'Content-Type': 'application/json'
    }
})
.then(response => response.json()) // Convert the response to JSON
.then(data => {
    if (data && data.ticket_id) { // Check if ticket_id exists in the response
        ticket_id_book = data.ticket_id;
        console.log("Fetched last ticket ID:", ticket_id_book);
    } else {
        console.error("No ticket data found in the response");
    }
})
.catch(error => {
    console.error('Error fetching the last ticket ID:', error);
});


console.log(ticket_id_book);
// Function to fetch booked seats and initialize seat states
function occupy_booked_seats() {
    var url = `http://localhost:8080/user/booked_seats?bus_name=${encodeURIComponent(window.bus_name_export)}`;
    fetch(url, {
        method: 'GET',
        headers: {
            'Content-Type': 'application/json'
        }
    })
    .then(response => response.json())
    .then(data => {
        if (data) {
            booked = data.map(seat => seat.seat_no); // Assuming 'seat_no' is the booked seat number
            console.log('Booked seats:', booked);
            initializeSeats(); // Initialize seats after fetching data
        }
    })
    .catch(error => {
        console.error('Error fetching booked seats:', error);
    });
}

// Function to initialize seats and handle click events
function initializeSeats() {
    // Only initialize seats if they haven't been initialized already
    if (document.querySelectorAll('.seat').length === 0) return;

    document.querySelectorAll('.seat').forEach((element, index) => {
        // Initialize the status on the element
        element.status = false;

        // If the seat is booked, set its background to red and prevent toggling
        if (booked.includes(index)) {
            element.style.backgroundColor = 'red';
            element.status = true; // Set the status to true for booked seats to prevent toggling
        }

        element.addEventListener("click", function() {
            // Toggle the seat only if it is not booked
            if (!booked.includes(index)) {
                if (!this.status) {
                    this.style.backgroundColor = "green";
                    this.status = true;
                    if (!selected_seats.includes(index)) {
                        selected_seats.push(index); // Add to selected seats if it's newly selected
                    }
                } else {
                    this.style.backgroundColor = 'rgb(242, 198, 167)';
                    this.status = false;
                    selected_seats = selected_seats.filter(seat => seat !== index); // Remove from selected seats if it's deselected
                }
                
                console.log(`Seat ${index} clicked. New status: ${this.status}`);
            } else {
                console.log(`Seat ${index} is booked and cannot be toggled.`);
            }
        });
    });
}

// Call occupy_booked_seats when the page loads or when needed
occupy_booked_seats();

// Show seat selection panel
function seat() {
    document.getElementById('select-seat').style.display = 'block';
}

// Button to log selected seats
document.querySelector('#button-for-book-seat').addEventListener('click', function() {
    // Display or log the selected seats
    if (selected_seats.length > 0) {
        alert("Selected seats: " + selected_seats.length);
        console.log("Indexes of selected seats:", selected_seats);
    } else {
        alert("No seats selected.");
    }
    
    // Send booking data
    selected_seats.forEach(seat => {
        const bookingData = {
            id: ++ticket_id_book, // Increment ticket_id_book and assign it
            c_name: prompt("Enter Name"), // Example customer name
            b_name: window.bus_name_export, // Example bus name
            pickup: window.picking_station, // Example pickup location
            drop: window.droping_station, // Example drop location
            seat_no: seat // Assign seat for this booking
        };

        alltck.push(bookingData.id); // Collect all ticket IDs
        
        fetch('http://localhost:8080/user/book', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(bookingData)
        })
        .then(response => response.json())
        .then(data => {
            if (data.error) {
                console.error('Error:', data.error);
            } else {
                console.log('Booking successful:', data.message);
            }
        })
        .catch((error) => {
            console.error('Error:', error);
        });
    });

    // Show the ticket IDs after booking
    setTimeout(() => {
        document.querySelector('#final-div').style.display = 'block';
        const displayArea = document.querySelector('#final-div pre');
        displayArea.innerHTML = "<h1>Your Booking IDs are: </h1>";
        displayArea.innerText+=alltck.join(',');
    }, 1000);

    // Attach event listener to the button inside #final-div
    document.querySelector('#final-div button').addEventListener('click', function() {
        document.querySelector('#final-div').style.display = 'none';
    });
});
