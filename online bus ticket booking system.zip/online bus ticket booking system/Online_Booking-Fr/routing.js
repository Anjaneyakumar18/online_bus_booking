

var menuitems = document.querySelectorAll('ul li a');
var home_cont = document.getElementById('home-cont');
var busdetails_cont = document.getElementById('busdetails-cont');
var bookticket_cont = document.getElementById('bookticket-cont');
var complaitus_cont = document.getElementById('complaintus-cont');
var getmytck_cont=document.getElementById('getmytck-cont');
var deletetck_cont=document.getElementById('deletetck-cont');
var select_seat=document.getElementById('select-seat');
var current = home_cont;

menuitems.forEach((ele, index) => {
    ele.addEventListener('click', () => {
        // Hide the currently visible content
        current.style.display = 'none';

        // Show the clicked content and update the current variable
        switch (index) {
            case 0:
                home_cont.style.display = 'block';
                current = home_cont;
                select_seat.style.display='none';
                break;
            case 1:
                bookticket_cont.style.display = 'block';
                current = bookticket_cont;
                select_seat.style.display='none';

                break;
            case 2:
                busdetails_cont.style.display = 'block';
                current = busdetails_cont;
                select_seat.style.display='none';

                break;
            case 5:
                complaitus_cont.style.display = 'block';
                current = complaitus_cont;
                select_seat.style.display='none';

                break;
            case 3:
                getmytck_cont.style.display='block';
                current=getmytck_cont;
                select_seat.style.display='none';

                break;
            case 4:
                deletetck_cont.style.display='block';
                current=deletetck_cont;
                select_seat.style.display='none';

                break;
        }
    });
});
